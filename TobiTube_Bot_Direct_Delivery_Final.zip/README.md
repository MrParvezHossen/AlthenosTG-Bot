# TobiTube Bot — Direct Telegram Delivery Edition

The redirect website and 15-second countdown have been removed.

The bot now creates a direct Telegram deep link. When the user clicks it, Telegram opens the bot, the bot validates the secure single-use token, checks optional Force Join requirements, retrieves the batch from the private Storage Channel, and sends the requested file(s).

See `telegram-bot/README.md` for complete setup and deployment instructions.
