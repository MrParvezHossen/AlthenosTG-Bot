# TobiTube Bot — Direct Telegram File Delivery

## Architecture

This version does **not** redirect users to a website and has **no 15-second countdown**.

```text
Admin uploads → Private Storage Channel
              → MongoDB metadata
              → Get Link
              → t.me/BOT?start=SECURE_TOKEN
              → Telegram /start
              → Token + Force Join verification
              → File copied directly to the user
```

### Data storage
- **MongoDB:** primary database for users, batches, files, tokens and download records.
- **Storage Channel:** private Telegram channel holding the original files.
- **Log Channel:** backup/audit channel for successful deliveries.

A successful delivery writes a message like:

```text
#DOWNLOAD

👤 Ayaan (@username)
🆔 123456789
📁 Movie.mp4
🗂 Batch: BATCH-...
🕒 19 Aug 2026, 10:20 PM
```

The log channel is not used as the primary database.

## Requirements

- Python 3.11+ if running without Docker
- Docker + Docker Compose (recommended)
- Telegram Bot Token
- Telegram API ID and API Hash
- Admin Telegram numeric ID
- Private Storage Channel where the bot is an administrator
- Optional private Log Channel where the bot can post messages
- MongoDB (included in Docker Compose)

## Configuration

Copy `.env.example` to `.env`:

```bash
cp .env.example .env
```

Required:

```env
BOT_TOKEN=
API_ID=
API_HASH=
BOT_USERNAME=
ADMIN_ID=
STORAGE_CHANNEL_ID=
LOG_CHANNEL_ID=
MONGO_URI=mongodb://mongo:27017
MONGO_DATABASE=telegram_file_bot
SECRET_KEY=
```

Generate the secret:

```bash
openssl rand -hex 32
```

For Bangladesh-style timestamps, keep:

```env
LOG_TIMEZONE=Asia/Dhaka
```

`WEBSITE_URL` is retained only as a legacy compatibility setting and is not used in direct delivery.

## Docker deployment

```bash
cd telegram-bot
docker compose up -d --build
docker compose ps
docker compose logs -f app
```

Health check:

```bash
curl http://127.0.0.1:8000/health
```

Expected:

```json
{"status":"ok"}
```

## Telegram setup

1. Create the bot with BotFather.
2. Add the bot as administrator to the private Storage Channel.
3. Create a private Log Channel and add the bot as administrator if `LOG_CHANNEL_ID` is enabled.
4. Put the numeric channel IDs into `.env`.
5. Start the application.
6. Sign in as the configured admin and use the Admin Panel.
7. Upload one or more files, then choose **Get Link**.
8. Open the generated `t.me/...start=...` link from a normal user account.
9. If Force Join is configured, join the required channels and tap **I've Joined**.
10. The bot sends the stored file(s) directly in Telegram.
11. Verify the corresponding `#DOWNLOAD` message in the Log Channel.

## Security

- Signed HMAC-SHA256 tokens
- Token TTL and single-use claim
- Start rate limiting
- Admin-only panel
- Force Join checks with admin bypass
- MongoDB is internal to Docker Compose
- No bot token/API secret is sent to the website
- Website redirect/countdown is not part of this version
