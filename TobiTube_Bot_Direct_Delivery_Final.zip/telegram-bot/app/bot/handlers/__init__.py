from .start import register as register_start
from .admin import register as register_admin
from .upload import register as register_upload

def register_all(app):
    register_start(app)
    register_admin(app)
    register_upload(app)
