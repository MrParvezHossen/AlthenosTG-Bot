from pyrogram import filters
from pyrogram.handlers import CallbackQueryHandler
from app.bot.handlers.common import is_admin
from app.bot.keyboards.admin_kb import admin_panel, upload_controls
from app.database.users import get_user_count
from app.database.batches import get_batch_count, get_recent_batches
from app.database.files import get_file_count
from app.database.downloads import get_download_count

async def admin_callback(client, callback):
    if not callback.from_user or not is_admin(callback.from_user.id):
        await callback.answer("⛔ You are not authorized.", show_alert=True)
        return
    action = callback.data.split(":", 1)[1]
    if action == "upload":
        from app.bot.handlers.upload import start_upload
        await start_upload(client, callback.message)
    elif action == "stats":
        text = (
            "📊 **Statistics**\n\n"
            f"👤 Users: `{await get_user_count()}`\n"
            f"📁 Active Batches: `{await get_batch_count()}`\n"
            f"📄 Stored Files: `{await get_file_count()}`\n"
            f"⬇️ Downloads: `{await get_download_count()}`"
        )
        await callback.message.edit_text(text, reply_markup=admin_panel())
    elif action == "recent":
        batches = await get_recent_batches(10)
        if not batches:
            text = "📋 No batches found."
        else:
            lines = ["📋 **Recent Batches**", ""]
            for b in batches:
                lines.append(f"• `{b['batch_id']}` — {b.get('file_count', 0)} file(s) — {b.get('status', 'unknown')}")
            text = "\n".join(lines)
        await callback.message.edit_text(text, reply_markup=admin_panel())
    elif action == "close":
        await callback.message.edit_text("Admin panel closed.")
    await callback.answer()


def register(app):
    app.add_handler(CallbackQueryHandler(admin_callback, filters.regex(r"^admin:")), group=1)
