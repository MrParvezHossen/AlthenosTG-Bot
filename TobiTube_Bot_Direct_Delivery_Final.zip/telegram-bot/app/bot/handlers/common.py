from pyrogram.types import Message
from pyrogram.enums import ChatMemberStatus
from app.config import settings


def is_admin(user_id: int) -> bool:
    return int(user_id) == settings.ADMIN_ID

async def missing_required_channels(client, user_id: int):
    missing = []
    for channel in settings.required_channels:
        try:
            member = await client.get_chat_member(channel["chat_id"], user_id)
            status = str(member.status).lower()
            if status.endswith("owner") or status.endswith("administrator") or status.endswith("member"):
                continue
            if status.endswith("restricted") and getattr(member, "is_member", True):
                continue
            missing.append(channel)
        except Exception:
            missing.append(channel)
    return missing
