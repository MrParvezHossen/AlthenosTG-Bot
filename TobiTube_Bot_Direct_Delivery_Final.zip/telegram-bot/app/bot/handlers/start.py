from pyrogram import filters
from pyrogram.handlers import MessageHandler
from app.config import settings
from app.bot.handlers.common import is_admin, missing_required_channels
from app.bot.keyboards.admin_kb import admin_panel, force_join_keyboard
from app.database.users import get_or_create_user
from app.database.batches import get_batch
from app.database.files import get_files_by_batch
from app.database.tokens import get_token, claim_token
from app.security.tokens import verify_token
from app.services.download_service import send_files_to_user
from app.utils.rate_limit import start_limiter
from app.utils.logger import logger

async def start_handler(client, message):
    user = message.from_user
    if not user:
        return
    if not await start_limiter.allow(str(user.id)):
        await message.reply_text("⏳ Too many requests. Please try again shortly.")
        return

    await get_or_create_user(user.id, user.username or "", user.first_name or "", user.last_name or "", user.language_code or "")
    parts = (message.text or "").split(maxsplit=1)
    token = parts[1].strip() if len(parts) == 2 else ""

    if not token:
        if is_admin(user.id):
            await message.reply_text("🛠 Admin Panel", reply_markup=admin_panel())
        else:
            await message.reply_text("👋 Welcome!\n\nSend a valid download link to receive your file.")
        return

    valid, _, error = verify_token(token)
    if not valid:
        await message.reply_text(f"❌ {error}")
        return

    token_doc = await get_token(token)
    if not token_doc:
        await message.reply_text("❌ This download link is invalid or no longer available.")
        return

    batch_id = token_doc["batch_id"]
    batch = await get_batch(batch_id)
    if not batch or batch.get("status") != "active":
        await message.reply_text("❌ This file link is no longer available.")
        return

    missing = [] if is_admin(user.id) else await missing_required_channels(client, user.id)
    if missing:
        await message.reply_text(
            "📢 Please join the required channel(s) first, then tap **I've Joined**.",
            reply_markup=force_join_keyboard(missing, settings.BOT_USERNAME, token),
        )
        return

    files = await get_files_by_batch(batch_id)
    if not files:
        await message.reply_text("❌ The requested file is missing from storage.")
        return

    claimed = await claim_token(token, user.id)
    if not claimed:
        await message.reply_text("⚠️ This download link has already been used.")
        return

    sent = await send_files_to_user(client, user, files, batch_id)
    if sent == len(files):
        await message.reply_text("📦 Your file is ready." if sent == 1 else "📦 Your files are ready.")
        logger.info("download completed: batch=%s user=%s files=%s", batch_id, user.id, sent)
    elif sent > 0:
        await message.reply_text(f"📦 {sent} of {len(files)} files were delivered. Some files could not be sent.")
    else:
        await message.reply_text("❌ The file could not be delivered right now. Please contact the administrator.")


def register(app):
    app.add_handler(MessageHandler(start_handler, filters.command("start") & filters.private), group=0)
