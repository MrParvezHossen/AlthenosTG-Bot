import secrets
import time
from pyrogram import filters
from pyrogram.handlers import MessageHandler, CallbackQueryHandler
from app.config import settings
from app.bot.handlers.common import is_admin
from app.bot.keyboards.admin_kb import upload_controls, admin_panel
from app.database.batches import create_batch, update_batch_file_count, cancel_batch
from app.database.files import add_file_to_batch
from app.database.tokens import create_token
from app.security.tokens import generate_secure_token
from app.services.storage import copy_to_storage, file_metadata, is_file_message
from app.utils.logger import logger

_sessions: dict[int, dict] = {}


def _cleanup_expired(user_id: int):
    session = _sessions.get(user_id)
    if session and time.time() - session["created_at"] > settings.UPLOAD_SESSION_TTL:
        _sessions.pop(user_id, None)

async def start_upload(client, message):
    user_id = message.from_user.id
    _cleanup_expired(user_id)
    if user_id in _sessions:
        await message.reply_text("⚠️ An upload session is already open.", reply_markup=upload_controls())
        return
    batch_id = f"BATCH_{secrets.token_hex(5).upper()}"
    _sessions[user_id] = {"batch_id": batch_id, "file_count": 0, "created_at": time.time()}
    await message.reply_text("📤 **Upload Mode**\n\nSend one or more files.\nWhen finished, choose an option below.", reply_markup=upload_controls())

async def receive_file(client, message):
    user = message.from_user
    if not user or not is_admin(user.id):
        return
    _cleanup_expired(user.id)
    session = _sessions.get(user.id)
    if not session:
        return
    if not is_file_message(message):
        await message.reply_text("⚠️ Please send a file/media message while Upload Mode is active.", reply_markup=upload_controls())
        return
    try:
        if session["file_count"] == 0:
            await create_batch(session["batch_id"], user.id, 0)
        stored = await copy_to_storage(message)
        filename, size, mime = file_metadata(message)
        await add_file_to_batch(session["batch_id"], settings.STORAGE_CHANNEL_ID, stored.id, filename, size, mime, user.id)
        session["file_count"] += 1
        session["created_at"] = time.time()
        await update_batch_file_count(session["batch_id"], session["file_count"])
        await message.reply_text(f"✅ Added: `{filename}`\n📦 Files in batch: {session['file_count']}", reply_markup=upload_controls())
    except Exception as exc:
        logger.error("upload failed: %s", exc)
        await message.reply_text("❌ The file could not be stored. Please try again.", reply_markup=upload_controls())

async def upload_callback(client, callback):
    user_id = callback.from_user.id
    if not is_admin(user_id):
        await callback.answer("⛔ You are not authorized.", show_alert=True)
        return
    _cleanup_expired(user_id)
    session = _sessions.get(user_id)
    action = callback.data.split(":", 1)[1]
    if action == "add_more":
        if not session:
            await callback.message.edit_text("Upload session expired. Start a new upload.", reply_markup=admin_panel())
        else:
            await callback.answer("Send the next file now.")
        return
    if action == "cancel":
        if session:
            if session["file_count"]:
                await cancel_batch(session["batch_id"])
            _sessions.pop(user_id, None)
        await callback.message.edit_text("❌ Upload cancelled.", reply_markup=admin_panel())
        await callback.answer()
        return
    if action == "get_link":
        if not session or session["file_count"] == 0:
            await callback.answer("Upload at least one file first.", show_alert=True)
            return
        token = generate_secure_token(session["batch_id"])
        valid, issued_at, _ = __import__("app.security.tokens", fromlist=["verify_token"]).verify_token(token)
        if not valid or issued_at is None:
            await callback.answer("Could not create a secure link. Try again.", show_alert=True)
            return
        await create_token(token, session["batch_id"], issued_at, settings.TOKEN_TTL)
        link = f"https://t.me/{settings.BOT_USERNAME}?start={token}"
        count = session["file_count"]
        _sessions.pop(user_id, None)
        await callback.message.edit_text(
            f"🔗 **Download Link Created**\n\n📦 Files: `{count}`\n🆔 Batch: `{session['batch_id']}`\n\n`{link}`",
            reply_markup=admin_panel(),
            disable_web_page_preview=True,
        )
        await callback.answer("Link created.")


def register(app):
    app.add_handler(MessageHandler(receive_file, filters.private & filters.media), group=2)
    app.add_handler(CallbackQueryHandler(upload_callback, filters.regex(r"^upload:")), group=3)
