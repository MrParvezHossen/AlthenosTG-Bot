from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup


def admin_panel():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📤 Upload File", callback_data="admin:upload")],
        [InlineKeyboardButton("📊 Statistics", callback_data="admin:stats"), InlineKeyboardButton("📋 Recent Files", callback_data="admin:recent")],
        [InlineKeyboardButton("❌ Close", callback_data="admin:close")],
    ])


def upload_controls():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🔗 Get Link", callback_data="upload:get_link")],
        [InlineKeyboardButton("➕ Add More File", callback_data="upload:add_more")],
        [InlineKeyboardButton("❌ Cancel", callback_data="upload:cancel")],
    ])


def force_join_keyboard(channels: list[dict], bot_username: str, token: str):
    buttons = []
    for channel in channels:
        url = channel.get("url") or ""
        if url:
            buttons.append([InlineKeyboardButton(f"📢 {channel['title']}", url=url)])
    buttons.append([InlineKeyboardButton("✅ I've Joined", url=f"https://t.me/{bot_username}?start={token}")])
    return InlineKeyboardMarkup(buttons)
