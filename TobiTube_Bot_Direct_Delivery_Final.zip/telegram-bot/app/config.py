import json
from typing import Optional
from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    BOT_TOKEN: str
    API_ID: int
    API_HASH: str
    BOT_USERNAME: str
    ADMIN_ID: int

    STORAGE_CHANNEL_ID: int
    LOG_CHANNEL_ID: Optional[int] = None

    MONGO_URI: str = "mongodb://mongo:27017"
    MONGO_DATABASE: str = "telegram_file_bot"

    SECRET_KEY: str = Field(min_length=32)
    # Legacy setting kept for compatibility; direct delivery does not use it.
    WEBSITE_URL: str = ""
    LOG_TIMEZONE: str = "Asia/Dhaka"
    TOKEN_TTL: int = Field(default=86400, ge=60, le=604800)
    UPLOAD_SESSION_TTL: int = Field(default=1800, ge=300, le=86400)
    REQUIRED_CHANNELS: str = "[]"
    START_RATE_LIMIT: int = Field(default=10, ge=1, le=100)
    START_RATE_WINDOW: int = Field(default=60, ge=10, le=3600)

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    @field_validator("BOT_USERNAME")
    @classmethod
    def normalize_bot_username(cls, value: str) -> str:
        return value.strip().lstrip("@")

    @field_validator("WEBSITE_URL")
    @classmethod
    def normalize_website_url(cls, value: str) -> str:
        return value.strip().rstrip("/")

    @property
    def required_channels(self) -> list[dict]:
        try:
            value = json.loads(self.REQUIRED_CHANNELS or "[]")
            if not isinstance(value, list):
                raise ValueError
            result = []
            for item in value:
                if isinstance(item, dict) and "chat_id" in item:
                    result.append({
                        "chat_id": int(item["chat_id"]),
                        "title": str(item.get("title") or "Required Channel"),
                        "url": str(item.get("url") or "")
                    })
            return result
        except Exception:
            raise ValueError("REQUIRED_CHANNELS must be a JSON list of objects with chat_id/title/url")


settings = Settings()
