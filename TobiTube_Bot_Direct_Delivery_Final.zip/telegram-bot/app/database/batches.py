from datetime import datetime, timezone
from app.database.mongodb import db

async def create_batch(batch_id: str, created_by: int, file_count: int = 0):
    doc = {"batch_id": batch_id, "created_by": created_by, "created_at": datetime.now(timezone.utc), "file_count": file_count, "status": "active"}
    await db.db.batches.insert_one(doc)
    return doc

async def get_batch(batch_id: str):
    return await db.db.batches.find_one({"batch_id": batch_id})

async def update_batch_file_count(batch_id: str, file_count: int):
    await db.db.batches.update_one({"batch_id": batch_id}, {"$set": {"file_count": file_count}})

async def cancel_batch(batch_id: str):
    await db.db.batches.update_one({"batch_id": batch_id}, {"$set": {"status": "cancelled"}})

async def get_recent_batches(limit: int = 10):
    return await db.db.batches.find().sort("created_at", -1).limit(limit).to_list(length=limit)

async def get_batch_count():
    return await db.db.batches.count_documents({"status": "active"})
