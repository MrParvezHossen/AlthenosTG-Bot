from datetime import datetime, timezone
from app.database.mongodb import db

async def record_download(user_id: int, batch_id: str, file_id: str, filename: str, status: str = "success"):
    await db.db.download_logs.insert_one({
        "user_id": user_id,
        "batch_id": batch_id,
        "file_id": str(file_id),
        "filename": filename,
        "downloaded_at": datetime.now(timezone.utc),
        "status": status,
    })

async def get_download_count():
    return await db.db.download_logs.count_documents({"status": "success"})
