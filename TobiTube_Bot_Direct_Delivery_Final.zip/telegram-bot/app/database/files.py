from datetime import datetime, timezone
from app.database.mongodb import db

async def add_file_to_batch(batch_id: str, storage_channel_id: int, message_id: int, filename: str,
                            file_size: int, mime_type: str, uploaded_by: int):
    doc = {
        "batch_id": batch_id,
        "storage_channel_id": storage_channel_id,
        "message_id": message_id,
        "filename": filename,
        "size": file_size,
        "mime_type": mime_type,
        "uploaded_by": uploaded_by,
        "created_at": datetime.now(timezone.utc),
    }
    result = await db.db.files.insert_one(doc)
    doc["_id"] = result.inserted_id
    return doc

async def get_files_by_batch(batch_id: str):
    return await db.db.files.find({"batch_id": batch_id}).sort("created_at", 1).to_list(length=None)

async def get_file_count():
    return await db.db.files.count_documents({})
