from motor.motor_asyncio import AsyncIOMotorClient
from app.config import settings
from app.utils.logger import logger


class MongoDB:
    client = None
    db = None

    async def connect(self):
        self.client = AsyncIOMotorClient(settings.MONGO_URI, serverSelectionTimeoutMS=5000, connectTimeoutMS=5000)
        await self.client.admin.command("ping")
        self.db = self.client[settings.MONGO_DATABASE]
        await self.setup_indexes()
        logger.info("database connected")

    async def close(self):
        if self.client:
            self.client.close()
            self.client = None
            self.db = None

    async def setup_indexes(self):
        await self.db.users.create_index("telegram_id", unique=True)
        await self.db.files.create_index("batch_id")
        await self.db.batches.create_index("batch_id", unique=True)
        await self.db.download_logs.create_index("user_id")
        await self.db.download_logs.create_index("batch_id")
        await self.db.download_logs.create_index("downloaded_at")
        await self.db.tokens.create_index("token_hash", unique=True)
        await self.db.tokens.create_index("expires_at", expireAfterSeconds=0)


db = MongoDB()
