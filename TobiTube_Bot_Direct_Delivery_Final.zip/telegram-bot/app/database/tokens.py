from datetime import datetime, timezone
from typing import Optional
from pymongo import ReturnDocument
from app.database.mongodb import db
from app.security.tokens import token_hash


async def create_token(token: str, batch_id: str, issued_at: int, ttl: int) -> None:
    now = datetime.now(timezone.utc)
    await db.db.tokens.insert_one({
        "token_hash": token_hash(token),
        "batch_id": batch_id,
        "issued_at": datetime.fromtimestamp(issued_at, tz=timezone.utc),
        "expires_at": datetime.fromtimestamp(issued_at + ttl, tz=timezone.utc),
        "created_at": now,
        "used_at": None,
        "used_by": None,
    })


async def get_token(token: str) -> Optional[dict]:
    return await db.db.tokens.find_one({"token_hash": token_hash(token)})


async def claim_token(token: str, user_id: int) -> Optional[dict]:
    return await db.db.tokens.find_one_and_update(
        {"token_hash": token_hash(token), "used_at": None},
        {"$set": {"used_at": datetime.now(timezone.utc), "used_by": user_id}},
        return_document=ReturnDocument.AFTER,
    )
