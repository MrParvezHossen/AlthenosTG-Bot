from datetime import datetime, timezone
from app.database.mongodb import db

async def get_or_create_user(telegram_id: int, username: str, first_name: str, last_name: str, language_code: str):
    now = datetime.now(timezone.utc)
    await db.db.users.update_one(
        {"telegram_id": telegram_id},
        {"$set": {"username": username or "", "first_name": first_name or "", "last_name": last_name or "", "language_code": language_code or "", "last_seen": now},
         "$setOnInsert": {"first_seen": now, "total_downloads": 0, "status": "active"}},
        upsert=True,
    )
    return await db.db.users.find_one({"telegram_id": telegram_id})

async def increment_user_download(telegram_id: int, count: int = 1):
    await db.db.users.update_one({"telegram_id": telegram_id}, {"$inc": {"total_downloads": count}})

async def get_user_count():
    return await db.db.users.count_documents({})
