import uvicorn
from contextlib import asynccontextmanager
from fastapi import FastAPI
from app.config import settings
from app.utils.logger import logger
from app.database.mongodb import db
from app.bot.client import bot
from app.bot.handlers import register_all
from app.web.routes import web_app

register_all(bot)

@asynccontextmanager
async def lifespan(_: FastAPI):
    logger.info("starting application")
    await db.connect()
    try:
        await bot.start()
        await bot.get_chat(settings.STORAGE_CHANNEL_ID)
        logger.info("bot started")
        yield
    finally:
        if bot.is_connected:
            await bot.stop()
            logger.info("bot stopped")
        await db.close()

app = FastAPI(title="TobiTube Bot", lifespan=lifespan)
app.mount("/", web_app)

if __name__ == "__main__":
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=False)
