import base64
import hashlib
import hmac
import secrets
import time
from typing import Optional, Tuple
from app.config import settings

# Telegram deep-link start parameters are short. The token is intentionally compact.
_VERSION = "1"
_SIG_BYTES = 16
_RANDOM_BYTES = 12


def _b64(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode().rstrip("=")


def _sign(payload: str) -> str:
    digest = hmac.new(settings.SECRET_KEY.encode(), payload.encode(), hashlib.sha256).digest()[:_SIG_BYTES]
    return _b64(digest)


def generate_secure_token(batch_id: str) -> str:
    issued_at = int(time.time())
    nonce = _b64(secrets.token_bytes(_RANDOM_BYTES))
    payload = f"{_VERSION}.{issued_at}.{nonce}"
    return f"{payload}.{_sign(payload)}"


def verify_token(token: str) -> Tuple[bool, Optional[int], Optional[str]]:
    try:
        if not token or len(token) > 64:
            return False, None, "Invalid token."
        parts = token.split(".")
        if len(parts) != 4 or parts[0] != _VERSION:
            return False, None, "Invalid token format."
        _, issued_at_str, nonce, signature = parts
        if not nonce or not signature or len(signature) != len(_sign(f"{_VERSION}.{issued_at_str}.{nonce}")):
            return False, None, "Invalid token signature."
        payload = f"{_VERSION}.{issued_at_str}.{nonce}"
        if not hmac.compare_digest(signature, _sign(payload)):
            return False, None, "Invalid token signature."
        issued_at = int(issued_at_str)
        now = int(time.time())
        if issued_at > now + 30:
            return False, None, "Invalid token timestamp."
        if now > issued_at + settings.TOKEN_TTL:
            return False, issued_at, "Token has expired."
        return True, issued_at, None
    except (TypeError, ValueError):
        return False, None, "Invalid token."
    except Exception:
        return False, None, "Token verification failed."


def token_hash(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()
