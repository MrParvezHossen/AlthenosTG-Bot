import asyncio
from pyrogram import Client
from pyrogram.errors import FloodWait, RPCError

from app.database.downloads import record_download
from app.database.users import increment_user_download
from app.services.log_channel import log_download_to_channel
from app.utils.logger import logger


async def _deliver_one(client: Client, user, file: dict, batch_id: str) -> bool:
    filename = file.get("filename", "unknown")
    try:
        await client.copy_message(user.id, file["storage_channel_id"], file["message_id"])
        await record_download(user.id, batch_id, str(file["_id"]), filename, "success")
        await log_download_to_channel(client, user, filename, batch_id)
        return True

    except FloodWait as exc:
        logger.warning("telegram flood wait: %s", exc.value)
        await asyncio.sleep(exc.value)
        try:
            await client.copy_message(user.id, file["storage_channel_id"], file["message_id"])
            await record_download(user.id, batch_id, str(file["_id"]), filename, "success")
            await log_download_to_channel(client, user, filename, batch_id)
            return True
        except Exception as retry_exc:
            logger.error("retry delivery failed: %s", retry_exc)
            await record_download(user.id, batch_id, str(file["_id"]), filename, "failed")
            return False

    except RPCError as exc:
        logger.error("telegram delivery failed: %s", exc)
        await record_download(user.id, batch_id, str(file["_id"]), filename, "failed")
        return False

    except Exception as exc:
        logger.error("unexpected delivery failure: %s", exc)
        await record_download(user.id, batch_id, str(file["_id"]), filename, "failed")
        return False


async def send_files_to_user(client: Client, user, files: list, batch_id: str) -> int:
    sent = 0
    for file in files:
        if await _deliver_one(client, user, file, batch_id):
            sent += 1
        await asyncio.sleep(0.4)

    if sent:
        await increment_user_download(user.id, sent)
    return sent
