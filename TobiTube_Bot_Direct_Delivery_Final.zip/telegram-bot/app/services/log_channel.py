from datetime import datetime
from zoneinfo import ZoneInfo

from pyrogram import Client
from pyrogram.errors import FloodWait, RPCError

from app.config import settings
from app.utils.logger import logger


def _display_name(user) -> str:
    first = (getattr(user, "first_name", "") or "").strip()
    last = (getattr(user, "last_name", "") or "").strip()
    username = (getattr(user, "username", "") or "").strip()
    name = " ".join(x for x in (first, last) if x).strip()
    if username:
        return f"{name} (@{username})" if name else f"@{username}"
    return name or "Unknown"


def _now_text() -> str:
    try:
        dt = datetime.now(ZoneInfo(settings.LOG_TIMEZONE))
    except Exception:
        dt = datetime.now()
    return dt.strftime("%d %b %Y, %I:%M %p")


async def log_download_to_channel(client: Client, user, filename: str, batch_id: str) -> bool:
    """Write a human-readable audit record to the configured private log channel."""
    if not settings.LOG_CHANNEL_ID:
        return True

    text = (
        "#DOWNLOAD\n\n"
        f"👤 {_display_name(user)}\n"
        f"🆔 {user.id}\n"
        f"📁 {filename}\n"
        f"🗂 Batch: {batch_id}\n"
        f"🕒 {_now_text()}"
    )

    try:
        await client.send_message(settings.LOG_CHANNEL_ID, text)
        return True
    except FloodWait as exc:
        logger.warning("log channel flood wait: %s seconds", exc.value)
        await __import__("asyncio").sleep(exc.value)
        try:
            await client.send_message(settings.LOG_CHANNEL_ID, text)
            return True
        except Exception as retry_exc:
            logger.error("download log retry failed: %s", retry_exc)
            return False
    except RPCError as exc:
        logger.error("download log channel RPC error: %s", exc)
        return False
    except Exception as exc:
        logger.error("download log channel error: %s", exc)
        return False
