from pyrogram import Client
from pyrogram.types import Message
from app.config import settings
from app.utils.logger import logger

SUPPORTED_MEDIA = ("document", "video", "audio", "photo", "animation", "voice", "video_note")

def is_file_message(message: Message) -> bool:
    return any(getattr(message, attr, None) is not None for attr in SUPPORTED_MEDIA)

def file_metadata(message: Message):
    media = None
    filename = "file"
    mime = "application/octet-stream"
    size = 0
    for attr in SUPPORTED_MEDIA:
        obj = getattr(message, attr, None)
        if obj is not None:
            media = obj
            filename = getattr(obj, "file_name", None) or filename
            mime = getattr(obj, "mime_type", None) or mime
            size = getattr(obj, "file_size", None) or size
            break
    if message.photo:
        filename = "photo.jpg"
        mime = "image/jpeg"
    return filename, int(size or 0), mime

async def copy_to_storage(message: Message) -> Message:
    copied = await message.copy(chat_id=settings.STORAGE_CHANNEL_ID)
    logger.info("file uploaded to storage: %s", copied.id)
    return copied

async def log_to_channel(client: Client, text: str):
    if not settings.LOG_CHANNEL_ID:
        return
    try:
        await client.send_message(settings.LOG_CHANNEL_ID, text)
    except Exception as exc:
        logger.error("log channel error: %s", exc)
