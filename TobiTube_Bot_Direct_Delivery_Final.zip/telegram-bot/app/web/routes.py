from fastapi import FastAPI
from app.config import settings

web_app = FastAPI()

@web_app.get("/health")
async def health_check():
    return {"status": "ok"}

@web_app.get("/")
async def root():
    return {"service": "TobiTube Bot", "status": "ok", "delivery": "telegram_direct"}
