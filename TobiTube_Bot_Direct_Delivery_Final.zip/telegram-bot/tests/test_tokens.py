import os
import unittest
from unittest.mock import patch

os.environ.setdefault("BOT_TOKEN", "123456:TEST")
os.environ.setdefault("API_ID", "123456")
os.environ.setdefault("API_HASH", "test_api_hash")
os.environ.setdefault("BOT_USERNAME", "test_bot")
os.environ.setdefault("ADMIN_ID", "123456789")
os.environ.setdefault("STORAGE_CHANNEL_ID", "-1001234567890")
os.environ.setdefault("SECRET_KEY", "x" * 64)
os.environ.setdefault("WEBSITE_URL", "")
os.environ.setdefault("TOKEN_TTL", "300")

from app.security.tokens import generate_secure_token, verify_token


class TokenTests(unittest.TestCase):
    def test_valid_token(self):
        token = generate_secure_token("BATCH_TEST")
        valid, issued_at, error = verify_token(token)
        self.assertTrue(valid)
        self.assertIsInstance(issued_at, int)
        self.assertIsNone(error)
        self.assertLessEqual(len(token), 64)

    def test_tampered_token_is_rejected(self):
        token = generate_secure_token("BATCH_TEST")
        parts = token.split(".")
        parts[2] = parts[2][:-1] + ("A" if parts[2][-1] != "A" else "B")
        tampered = ".".join(parts)
        valid, _, _ = verify_token(tampered)
        self.assertFalse(valid)

    def test_expired_token_is_rejected(self):
        with patch("app.security.tokens.time.time", return_value=1_000_000):
            token = generate_secure_token("BATCH_TEST")
        with patch("app.security.tokens.time.time", return_value=1_000_301):
            valid, _, error = verify_token(token)
        self.assertFalse(valid)
        self.assertEqual(error, "Token has expired.")


if __name__ == "__main__":
    unittest.main()
